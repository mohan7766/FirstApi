package com.accenture.pcm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PcmApplicationTests {

	@Test
	void contextLoads() {
	}

}
